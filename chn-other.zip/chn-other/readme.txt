This is the work of yuleeyeen. If you want to create a Chinese VB, you can use it.  
On Bilibili, I happened to find a CVV-style recording form VB. The amount recorded was small, and it has already become lost, so I made it.  
There may be differences from the original version.  
--From yuleeyeen

这是 yuleeyeen 的作品。如果你想创建一个中文 VB，可以使用它。 
在哔哩哔哩上，我偶然发现了一个 CVV 风格的录音 VB。录制的数量很少，而且已经丢失了，所以我做了这个。 
可能与原版有所不同。 推荐中国人使用
--来自 yuleeyeen